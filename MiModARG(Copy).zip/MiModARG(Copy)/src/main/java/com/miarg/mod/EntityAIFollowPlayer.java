package com.miarg.mod;

import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;

public class EntityAIFollowPlayer extends EntityAIBase {

    private final EntityMisteriosa entity;
    private final EntityPlayer player;
    private final double speed;
    private final float minDistance;

    public EntityAIFollowPlayer(EntityMisteriosa entity, EntityPlayer player, double speed, float minDistance) {
        this.entity = entity;
        this.player = player;
        this.speed = speed;
        this.minDistance = minDistance;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        return player != null && entity.getDistanceSq(player) > (minDistance * minDistance);
    }

    @Override
    public void updateTask() {
        this.entity.getLookHelper().setLookPositionWithEntity(player, 10.0F, (float)this.entity.getVerticalFaceSpeed());
        this.entity.getNavigator().tryMoveToEntityLiving(player, speed);
    }
}
