package com.miarg.mod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.List;

public class ChatEventHandler {

    @SubscribeEvent
    public void onPlayerChat(ServerChatEvent event) {
        String message = event.getMessage().toLowerCase().trim();
        EntityPlayer player = event.getPlayer();

        if (message.contains("what?") || message.contains("hello?")) {
            List<EntityMisteriosa> entities = player.world.getEntitiesWithinAABB(
                EntityMisteriosa.class, 
                player.getEntityBoundingBox().grow(50.0D)
            );

            for (EntityMisteriosa entity : entities) {
                entity.enableFollowing(player);
            }
        }
    }
}
