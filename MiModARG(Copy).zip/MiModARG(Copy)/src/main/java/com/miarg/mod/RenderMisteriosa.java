package com.miarg.mod;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderMisteriosa extends RenderLiving<EntityMisteriosa> {

    private static final ResourceLocation TEXTURE = new ResourceLocation("argmod", "textures/entity/misteriosa.png");

    public RenderMisteriosa(RenderManager renderManager) {
        super(renderManager, new ModelPlayer(0.0F, false), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityMisteriosa entity) {
        return TEXTURE;
    }
}
