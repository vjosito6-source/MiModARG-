package com.miarg.mod;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod(modid = "argmod", name = "ARG Mod", version = "1.0")
public class MiModARG {

    @Mod.Instance
    public static MiModARG instance;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // Registrar la entidad en el juego
        EntityRegistry.registerModEntity(
            new ResourceLocation("argmod", "misteriosa"),
            EntityMisteriosa.class,
            "misteriosa",
            1,
            this,
            64,
            1,
            true,
            0x000000, // Color del huevo de spawn (Negro)
            0xFF0000  // Puntos del huevo (Rojo)
        );

        // Registrar el detector del chat
        MinecraftForge.EVENT_BUS.register(new ChatEventHandler());
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide() == Side.CLIENT) {
            registerRenderers();
        }
    }

    @SideOnly(Side.CLIENT)
    private void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityMisteriosa.class, RenderMisteriosa::new);
    }
}
